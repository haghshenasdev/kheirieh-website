<section class="py-2 container">
    <div class="row align-items-center">
        <script>
            document.getElementById('application_title').innerHTML = "خطا";
        </script>
        <div class="col-lg-6 col-md-8 mx-auto ThemeStyle p-4 py-5 text-light text-center animated bounceInUp">

            <img src="<?= base_url("css/images/danger.svg") ?>" alt="" class="m-auto" width="50%">
            <h3>درخواست شما ثبت نشد !</h3>
            <p>لطفا مجددا تلاش کنید .</p>
            <div class="text-center">
                <button class="btn btn-outline-light mt-4 ThemeStyle-border" type="button" onclick="history.back()">بازگشت</button>
            </div>

        </div>
    </div>
</section>